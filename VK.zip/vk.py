import random
import datetime
import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
import requests
import pymorphy2
import math

# API-ключ созданный ранее
token = "ab9917ecf2d315ca983d39a046d434c45d18eae587b0deb140d63d8ded76ca4dddf623e0eabbe3b96c910"

town = "Абакан Азов Александров Алексин Альметьевск Анапа Ангарск Анжеро-Судженск Апатиты Арзамас " \
       "Армавир Арсеньев Артем Архангельск Асбест Астрахань Ачинск Балаково Балахна Балашиха Балашов " \
       "Барнаул Батайск Белгород Белебей Белово Белогорск (Амурская область) Белорецк Белореченск Бердск " \
       "Березники Березовский (Свердловская область) Бийск Биробиджан Благовещенск (Амурская область) Бор" \
       " Борисоглебск Боровичи Братск Брянск Бугульма Буденновск Бузулук Буйнакск Великие Луки Великий " \
       "Новгород Верхняя Пышма Видное Владивосток Владикавказ Владимир Волгоград Волгодонск Волжск " \
       "Волжский Вологда Вольск Воркута Воронеж Воскресенск Воткинск Всеволожск Выборг Выкса Вязьма" \
       " Гатчина Геленджик Георгиевск Глазов Горно-Алтайск Грозный Губкин Гудермес Гуково Гусь-Хрустальный " \
       "Дербент Дзержинск Димитровград Дмитров Долгопрудный Домодедово Донской Дубна Евпатория Егорьевск" \
       " Ейск Екатеринбург Елабуга Елец Ессентуки Железногорск (Красноярский край) Железногорск " \
       " Жигулевск Жуковский Заречный Зеленогорск Зеленодольск Златоуст Иваново Ивантеевка Ижевск " \
       "Избербаш Иркутск Искитим Ишим Ишимбай Йошкар-Ола Казань Калининград Калуга Каменск-Уральский " \
       "Каменск-Шахтинский Камышин Канск Каспийск Кемерово Керчь Кинешма Кириши Киров (Кировская область)" \
       " Кирово-Чепецк Киселевск Кисловодск Клин Клинцы Ковров Когалым Коломна Комсомольск-на-Амуре " \
       "Копейск Королев Кострома Котлас Красногорск Краснодар Краснокаменск Краснокамск Краснотурьинск " \
       "Красноярск Кропоткин Крымск Кстово Кузнецк Кумертау Кунгур Курган Курск Кызыл Лабинск Лениногорск " \
       "Ленинск-Кузнецкий Лесосибирск Липецк Лиски Лобня Лысьва Лыткарино Люберцы Магадан Магнитогорск " \
       "Майкоп Махачкала Междуреченск Мелеуз Миасс Минеральные Воды Минусинск Михайловка Михайловск " \
       "(Ставропольский край) Мичуринск Москва Мурманск Муром Мытищи Набережные Челны Назарово Назрань " \
       "Нальчик Наро-Фоминск Находка Невинномысск Нерюнгри Нефтекамск Нефтеюганск Нижневартовск Нижнекамск " \
       "Нижний Новгород Нижний Тагил Новоалтайск Новокузнецк Новокуйбышевск Новомосковск Новороссийск " \
       "Новосибирск Новотроицк Новоуральск Новочебоксарск Новочеркасск Новошахтинск Новый Уренгой Ногинск" \
       " Норильск Ноябрьск Нягань Обнинск Одинцово Озерск (Челябинская область) Октябрьский Омск Орел " \
       "Оренбург Орехово-Зуево Орск Павлово Павловский Посад Пенза Первоуральск Пермь Петрозаводск " \
       "Петропавловск-Камчатский Подольск Полевской Прокопьевск Прохладный Псков Пушкино Пятигорск " \
       "Раменское Ревда Реутов Ржев Рославль Россошь Ростов-на-Дону Рубцовск Рыбинск Рязань Салават " \
       "Сальск Самара Санкт-Петербург Саранск Сарапул Саратов Саров Свободный Севастополь Северодвинск " \
       "Северск Сергиев Посад Серов Серпухов Сертолово Сибай Симферополь Славянск-на-Кубани Смоленск" \
       " Соликамск Солнечногорск Сосновый Бор Сочи Ставрополь Старый Оскол Стерлитамак Ступино Сургут " \
       "Сызрань Сыктывкар Таганрог Тамбов Тверь Тимашевск Тихвин Тихорецк Тобольск Тольятти Томск Троицк" \
       " Туапсе Туймазы Тула Тюмень Узловая Улан-Удэ Ульяновск Урус-Мартан Усолье-Сибирское Уссурийск " \
       "Усть-Илимск Уфа Ухта Феодосия Фрязино Хабаровск Ханты-Мансийск Хасавюрт Химки Чайковский Чапаевск " \
       "Чебоксары Челябинск Черемхово Чаплыгин Череповец Черкесск Черногорск Чехов Чистополь Чита Шадринск Шали " \
       "Шахты Шуя Щекино Щелково Электросталь Элиста Энгельс Южно-Сахалинск Юрга Якутск Ялта Ярославль".lower().split()


def main():
    # Авторизуемся как сообщество
    vk = vk_api.VkApi(token=token)

    # Работа с сообщениями
    longpoll = VkBotLongPoll(vk, 204424831)

    for event in longpoll.listen():
        # Если пришло новое сообщение
        if event.type == VkBotEventType.MESSAGE_NEW:
            # Сообщение от пользователя
            request = event.message['text'].lower()

            if {'здравствуй', "хай", "хэй"} & set(request.split()) or 'прив' in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Здравствуй! Рады приветствовать тебя в нашем "
                                                   "чат-боте! Если ты обращаешься впервые, то "
                                                   "обязательно воспользуйся справкой (напиши "
                                                   "'Помощь')",
                                           random_id=random.randint(0, 2 ** 64))
            elif "час" in request or "врем" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message=datetime.datetime.now(),
                                           random_id=random.randint(0, 2 ** 64))
            elif "дела" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="У меня всё хорошо! А как может быть иначе,"
                                                   " если есть интересный собеседник! Думаю у вас "
                                                   "тоже все хорошо!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "делаешь" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Я не отличаюсь способностями Юлия Цезаря,"
                                                   " поэтому занята только общением с тобой",
                                           random_id=random.randint(0, 2 ** 64))
            elif "музык" in request or "песн" in request or "слуша" \
                    in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Я люблю разную музыку! Предлагаю тебе послушать"
                                                   " мой плейлист:\n"
                                                   "Expecting a Message - Kevin Godley\n"
                                                   "Grapes Of Wrath - Weezer\n"
                                                   "Tally-Ho - Psychedelic Porn Crumpets\n"
                                                   "Miracle - Pinemoon\n"
                                                   "Cloudspotter - Foo Fighters\n"
                                                   "Got So High - The Pretty Reckless\n"
                                                   "Asystole - Hayley Williams\n"
                                                   "What I Need - Pearl Charles\n"
                                                   "The Wrangler Man - Bjørn Berge\n"
                                                   "Miracle - Schiller, Tricia McTeague\n"
                                                   "Ocean Queen - Pastel Jungle\n"
                                                   "Pills - The Nova Hawks\n"
                                                   "Scream and Shout! - Hearty Har\n"
                                                   "Easy - Pale Waves",
                                           random_id=random.randint(0, 2 ** 64))
            elif "книги" in request or "чита" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Я обожаю читать! Думаю вам понравится:\n"
                                                   "Александр Сергеевич Грибоедов «Горе от ума»\n"
                                                   "Александр Сергеевич Пушкин «Евгений Онегин», «Пиковая дама», "
                                                   "«Медный всадник», «Моцарт и Сальери»\n"
                                                   "Михаил Юрьевич Лермонтов. «Герой нашего времени»\n"
                                                   "Николай Васильевич Гоголь «Мёртвые души», «Шинель»\n"
                                                   "Александр Николаевич Островский «Свои люди – сочтёмся!», "
                                                   "«За двумя зайцами», «На всякого мудреца довольно простоты»,"
                                                   " «Не всё коту масленица»\n"
                                                   "Фёдор Михайлович Достоевский «Белые ночи»\n"
                                                   "Лев Николаевич Толстой «Юность», «Севастопольские рассказы»\n"
                                                   "Антон Павлович Чехов «Шуточка», Студент»\n"
                                                   "Иван Алексеевич Бунин «Сны Чанга», «Господин из Сан-Франциско»\n"
                                                   "Михаил Афанасьевич Булгаков «Собачье сердце»,"
                                                   " «Записки молодого врача», «Роковые яйца»\n"
                                                   "Михаил Александрович Шолохов «Судьба человека»\n"
                                                   "Александр Исаевич Солженицын «Матрёнин двор»\n"
                                                   "А. и Б. Стругацкие «Обитаемый остров», "
                                                   "«Понедельник начинается в субботу»\n"
                                                   "М. Зощенко «Жертва революции», «Аристократка», «Нервные люди», "
                                                   "«Актер», «Тормоз Вестингауза»",
                                           random_id=random.randint(0, 2 ** 64))
            elif "анекдот" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Сидят две девочки на крыше… Одна добрая, другая злая и кидают "
                                                   "камни в прохожих, злая попала 3 раза, а добрая 5… Потому что добро "
                                                   "ВСЕГДА побеждает зло!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "смеш" in request or "ах" in request or "ха" in request or "спасиб" in request \
                    or "забавн" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Очень приятно радовать тебя!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "болта" in request or "поболта" in request or "говор" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Супер! Ты можешь задавать мне вопросы!"
                                                   " Я с удовольствием отвечу!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "шутк" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Урок химии.\n"
                                                   "Учительница:\n"
                                                   "- Маша, какого цвета у тебя раствор?\n"
                                                   "- Красного.\n"
                                                   "- Правильно. Садись, пять.\n"
                                                   "- Катя, а у тебя?\n"
                                                   "- Оранжевого.\n"
                                                   "- Не совсем правильно. Четыре, садись.\n"
                                                   "- Вовочка, цвет твоего раствора?\n"
                                                   "- Черный.\n"
                                                   "- Два. Класс! Ложись!!!!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "комп" in request and ("игр" in request or "поигр" in request):
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Компьютерные игры дело сложное! Могу посоветовать:\n"
                                                   "Genshin Impact\n"
                                                   "The Sims\n"
                                                   "Minecraft\n"
                                                   "PORTAL\n"
                                                   "CS:GO",
                                           random_id=random.randint(0, 2 ** 64))
            elif "телеф" in request and ("игр" in request or "поигр" in request):
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Игры для телефона незаметно отнимают много"
                                                   " времени! Но бывают понастоящему интересными!"
                                                   " Могу посоветовать:\n"
                                                   "Genshin Impact\n"
                                                   "The Sims\n"
                                                   "Minecraft\n"
                                                   "Doodle Jump\n"
                                                   "Dear My Cat\n"
                                                   "Sushi Bar\n"
                                                   "Flip the Frog\n"
                                                   "Color Switch",
                                           random_id=random.randint(0, 2 ** 64))
            elif "помощь" in request or "помоги" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message='С моей помощь можно: \n'
                                                   '- просто поболтать по душам или прочитать шутку;\n'
                                                   '- посоветовать игры, книги и музыку;\n'
                                                   '- посмотреть актуальные фото Марса;\n'
                                                   '- указать долготу и широту расположения заданного города;\n'
                                                   '- посчитать расстояние между заданными городами;\n'
                                                   '- показать погоду в заданном городе.',
                                           random_id=random.randint(0, 2 ** 64))
            elif "улиц" in request and ("игр" in request or "поигр" in request):
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Я обожаю гулять! Могу посоветовать уличные игры:\n"
                                                   "Футбол\n"
                                                   "Баскетбол\n"
                                                   "Волейбол\n"
                                                   "Светофор\n"
                                                   "Картошка\n"
                                                   "Колечко\n"
                                                   "Вышибалы\n"
                                                   "Казаки-разбойники",
                                           random_id=random.randint(0, 2 ** 64))
            elif "пока" in request or 'до свидания' in request or 'окончим разговор' in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Всего доброго! Было приятно пообщаться!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "марс" in request or "марса" in request:
                NASA_API_KEY = '643g44LeTfWdhwFk6VRZ03NW2WOBhuBUCIvB7ngT'
                ROVER_URL = 'https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos'
                sol = random.randint(0, 1722)
                params = {'sol': sol, 'api_key': NASA_API_KEY}
                rev = random.choice(requests.get(ROVER_URL, params=params).json()['photos'])[
                    'img_src']
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message=rev,
                                           random_id=random.randint(0, 2 ** 64))
            elif "погод".lower() in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message=weather(request.split()[-1][:-1]),
                                           random_id=random.randint(0, 2 ** 64))
            elif 'расстоян' in request or 'километр' in request and set(request.split()) & set(
                    town):
                morph = pymorphy2.MorphAnalyzer()
                goroda = []
                for s in request.split():
                    if morph.parse(s)[0].tag.POS != 'NOUN':
                        s = s[:-2]
                    if morph.parse(s)[0].normal_form in town:
                        goroda.append(morph.parse(s)[0].normal_form)
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message=str(round(
                                               get_distance(get_coordinates(goroda[0]),
                                                            get_coordinates(goroda[1])))) + ' км',
                                           random_id=random.randint(0, 2 ** 64))
            elif 'долгот' in request or "широт" in request:
                morph = pymorphy2.MorphAnalyzer()
                gorod = ''
                for s in request.split():
                    if morph.parse(s)[0].tag.POS != 'NOUN':
                        s = s[:-2]
                    if morph.parse(s)[0].normal_form in town:
                        gorod = morph.parse(s)[0].normal_form
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message=str(get_coordinates(gorod)) + ' - ' +
                                                   get_country(gorod),
                                           random_id=random.randint(0, 2 ** 64))
            else:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Не понял вашего ответа... Попробуйте еще раз",
                                           random_id=random.randint(0, 2 ** 64))


def weather(s_city):
    if s_city in ' '.join(town).lower():
        s_city = town[' '.join(town).lower().find(s_city) // len(town)]
    city_id = 0
    appid = "94030d7e142e2356494a0b52b0fdec62"
    try:
        res = requests.get("http://api.openweathermap.org/data/2.5/find",
                           params={'q': s_city, 'type': 'like', 'units': 'metric', 'APPID': appid})
        data = res.json()
        cities = ["{} ({})".format(d['name'], d['sys']['country'])
                  for d in data['list']]
        city_id = data['list'][0]['id']
    except Exception as e:
        print("Exception (find):", e)
        return e

    try:
        res = requests.get("http://api.openweathermap.org/data/2.5/forecast",
                           params={'id': city_id, 'units': 'metric', 'lang': 'ru', 'APPID': appid})
        data = res.json()
        for i in data['list'][:1]:
            return (i['dt_txt'], '{0:+1.0f}'.format(i['main']['temp']),
                    i['weather'][0]['description'])
    except Exception as e:
        print("Exception (forecast):", e)
        return e


def get_coordinates(city_name):
    try:
        # url, по которому доступно API Яндекс.Карт
        url = "https://geocode-maps.yandex.ru/1.x/"
        # параметры запроса
        params = {
            "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
            # город, координаты которого мы ищем
            'geocode': city_name,
            # формат ответа от сервера, в данном случае JSON
            'format': 'json'
        }
        # отправляем запрос
        response = requests.get(url, params)
        # получаем JSON ответа
        json = response.json()
        # получаем координаты города
        coordinates_str = json['response']['GeoObjectCollection'][
            'featureMember'][0]['GeoObject']['Point']['pos']
        # Превращаем string в список, так как
        # точка - это пара двух чисел - координат
        long, lat = map(float, coordinates_str.split())
        return long, lat
    except Exception as e:
        return None


def get_distance(p1, p2):
    # p1 и p2 - это кортежи из двух элементов - координаты точек
    radius = 6373.0

    lon1 = math.radians(p1[0])
    lat1 = math.radians(p1[1])
    lon2 = math.radians(p2[0])
    lat2 = math.radians(p2[1])

    d_lon = lon2 - lon1
    d_lat = lat2 - lat1

    a = math.sin(d_lat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(d_lon / 2) ** 2
    c = 2 * math.atan2(a ** 0.5, (1 - a) ** 0.5)

    distance = radius * c
    return distance


def get_country(city_name):
    try:
        url = "https://geocode-maps.yandex.ru/1.x/"
        params = {
            "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
            'geocode': city_name,
            'format': 'json'
        }
        data = requests.get(url, params).json()
        # все отличие тут, мы получаем имя страны
        return data['response']['GeoObjectCollection'][
            'featureMember'][0]['GeoObject']['metaDataProperty'][
            'GeocoderMetaData']['AddressDetails']['Country']['CountryName']
    except Exception as e:
        return e


if __name__ == '__main__':
    main()
