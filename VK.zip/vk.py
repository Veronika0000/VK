import random
import datetime
import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from vk_api.upload import VkUpload
from vk_api.utils import get_random_id
from aiohttp import web, ClientSession
from io import BytesIO
import requests
import math

# API-ключ созданный ранее
token = "0565c4f4b66f8c4cb502d4650583ed57240847796ec61ea6d171c20c63f2cb8263d2e32fecfaac1672242"

town = "Абакан Азов Александров Алексин Альметьевск Анапа Ангарск Анжеро-Судженск Апатиты Арзамас " \
       "Армавир Арсеньев Артем Архангельск Асбест Астрахань Ачинск Балаково Балахна Балашиха Балашов " \
       "Барнаул Батайск Белгород Белебей Белово Белогорск (Амурская область) Белорецк Белореченск Бердск " \
       "Березники Березовский (Свердловская область) Бийск Биробиджан Благовещенск (Амурская область) Бор" \
       " Борисоглебск Боровичи Братск Брянск Бугульма Буденновск Бузулук Буйнакск Великие Луки Великий " \
       "Новгород Верхняя Пышма Видное Владивосток Владикавказ Владимир Волгоград Волгодонск Волжск " \
       "Волжский Вологда Вольск Воркута Воронеж Воскресенск Воткинск Всеволожск Выборг Выкса Вязьма" \
       " Гатчина Геленджик Георгиевск Глазов Горно-Алтайск Грозный Губкин Гудермес Гуково Гусь-Хрустальный " \
       "Дербент Дзержинск Димитровград Дмитров Долгопрудный Домодедово Донской Дубна Евпатория Егорьевск" \
       " Ейск Екатеринбург Елабуга Елец Ессентуки Железногорск (Красноярский край) Железногорск " \
       " Жигулевск Жуковский Заречный Зеленогорск Зеленодольск Златоуст Иваново Ивантеевка Ижевск " \
       "Избербаш Иркутск Искитим Ишим Ишимбай Йошкар-Ола Казань Калининград Калуга Каменск-Уральский " \
       "Каменск-Шахтинский Камышин Канск Каспийск Кемерово Керчь Кинешма Кириши Киров (Кировская область)" \
       " Кирово-Чепецк Киселевск Кисловодск Клин Клинцы Ковров Когалым Коломна Комсомольск-на-Амуре " \
       "Копейск Королев Кострома Котлас Красногорск Краснодар Краснокаменск Краснокамск Краснотурьинск " \
       "Красноярск Кропоткин Крымск Кстово Кузнецк Кумертау Кунгур Курган Курск Кызыл Лабинск Лениногорск " \
       "Ленинск-Кузнецкий Лесосибирск Липецк Лиски Лобня Лысьва Лыткарино Люберцы Магадан Магнитогорск " \
       "Майкоп Махачкала Междуреченск Мелеуз Миасс Минеральные Воды Минусинск Михайловка Михайловск " \
       "(Ставропольский край) Мичуринск Москва Мурманск Муром Мытищи Набережные Челны Назарово Назрань " \
       "Нальчик Наро-Фоминск Находка Невинномысск Нерюнгри Нефтекамск Нефтеюганск Нижневартовск Нижнекамск " \
       "Нижний Новгород Нижний Тагил Новоалтайск Новокузнецк Новокуйбышевск Новомосковск Новороссийск " \
       "Новосибирск Новотроицк Новоуральск Новочебоксарск Новочеркасск Новошахтинск Новый Уренгой Ногинск" \
       " Норильск Ноябрьск Нягань Обнинск Одинцово Озерск (Челябинская область) Октябрьский Омск Орел " \
       "Оренбург Орехово-Зуево Орск Павлово Павловский Посад Пенза Первоуральск Пермь Петрозаводск " \
       "Петропавловск-Камчатский Подольск Полевской Прокопьевск Прохладный Псков Пушкино Пятигорск " \
       "Раменское Ревда Реутов Ржев Рославль Россошь Ростов-на-Дону Рубцовск Рыбинск Рязань Салават " \
       "Сальск Самара Санкт-Петербург Саранск Сарапул Саратов Саров Свободный Севастополь Северодвинск " \
       "Северск Сергиев Посад Серов Серпухов Сертолово Сибай Симферополь Славянск-на-Кубани Смоленск" \
       " Соликамск Солнечногорск Сосновый Бор Сочи Ставрополь Старый Оскол Стерлитамак Ступино Сургут " \
       "Сызрань Сыктывкар Таганрог Тамбов Тверь Тимашевск Тихвин Тихорецк Тобольск Тольятти Томск Троицк" \
       " Туапсе Туймазы Тула Тюмень Узловая Улан-Удэ Ульяновск Урус-Мартан Усолье-Сибирское Уссурийск " \
       "Усть-Илимск Уфа Ухта Феодосия Фрязино Хабаровск Ханты-Мансийск Хасавюрт Химки Чайковский Чапаевск " \
       "Чебоксары Челябинск Черемхово Чаплыгин Череповец Черкесск Черногорск Чехов Чистополь Чита Шадринск Шали " \
       "Шахты Шуя Щекино Щелково Электросталь Элиста Энгельс Южно-Сахалинск Юрга Якутск Ялта Ярославль".lower().split()


def main():
    # Авторизуемся как сообщество
    vk = vk_api.VkApi(token=token)
    upload = VkUpload(vk)

    # Работа с сообщениями
    longpoll = VkBotLongPoll(vk)

    for event in longpoll.listen():
        # Если пришло новое сообщение
        if event.type == VkBotEventType.MESSAGE_NEW:
            # Сообщение от пользователя
            request = event.message['text'].lower()

            if "привет" in request or "ку" in request or "хай" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Привет",
                                           random_id=random.randint(0, 2 ** 64))
            elif "который час?" in request or "сколько времени?" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message=datetime.datetime.now(),
                                           random_id=random.randint(0, 2 ** 64))
            elif "как дела?" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Всё хорошо!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "что делаешь?" in request or "а что делаешь?" in request or "а что ты делаешь?" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Общаюсь с вами",
                                           random_id=random.randint(0, 2 ** 64))
            elif "и как тебе?" in request or "как тебе?" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Мне всё нравится!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "какая музыка тебе нравится?" in request or "какую музыку ты любишь?" in request or "что ты слушаешь?" \
                    in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Я люблю разную музыку!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "а какая больше всего?" in request or "какая больше всего?" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Мне нравится всё",
                                           random_id=random.randint(0, 2 ** 64))
            elif "посоветуй песни" in request or "что можно послушать?" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Думаю вам понравится:\n"
                                                   "Expecting a Message - Kevin Godley\n"
                                                   "Grapes Of Wrath - Weezer\n"
                                                   "Tally-Ho - Psychedelic Porn Crumpets\n"
                                                   "Miracle - Pinemoon\n"
                                                   "Cloudspotter - Foo Fighters\n"
                                                   "Got So High - The Pretty Reckless\n"
                                                   "Asystole - Hayley Williams\n"
                                                   "What I Need - Pearl Charles\n"
                                                   "The Wrangler Man - Bjørn Berge\n"
                                                   "Miracle - Schiller, Tricia McTeague\n"
                                                   "Ocean Queen - Pastel Jungle\n"
                                                   "Pills - The Nova Hawks\n"
                                                   "Scream and Shout! - Hearty Har\n"
                                                   "Easy - Pale Waves",
                                           random_id=random.randint(0, 2 ** 64))
            elif "посоветуй книги" in request or "что можно почитать?" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Думаю вам понравится:\n"
                                                   "Александр Сергеевич Грибоедов «Горе от ума»\n"
                                                   "Александр Сергеевич Пушкин «Евгений Онегин», «Пиковая дама», "
                                                   "«Медный всадник», «Моцарт и Сальери»\n"
                                                   "Михаил Юрьевич Лермонтов. «Герой нашего времени»\n"
                                                   "Николай Васильевич Гоголь «Мёртвые души», «Шинель»\n"
                                                   "Александр Николаевич Островский «Свои люди – сочтёмся!», "
                                                   "«За двумя зайцами», «На всякого мудреца довольно простоты»,"
                                                   " «Не всё коту масленица»\n"
                                                   "Фёдор Михайлович Достоевский «Белые ночи»\n"
                                                   "Лев Николаевич Толстой «Юность», «Севастопольские рассказы»\n"
                                                   "Антон Павлович Чехов «Шуточка», Студент»\n"
                                                   "Иван Алексеевич Бунин «Сны Чанга», «Господин из Сан-Франциско»\n"
                                                   "Михаил Афанасьевич Булгаков «Собачье сердце»,"
                                                   " «Записки молодого врача», «Роковые яйца»\n"
                                                   "Михаил Александрович Шолохов «Судьба человека»\n"
                                                   "Александр Исаевич Солженицын «Матрёнин двор»\n"
                                                   "А. и Б. Стругацкие «Обитаемый остров», "
                                                   "«Понедельник начинается в субботу»\n"
                                                   "М. Зощенко «Жертва революции», «Аристократка», «Нервные люди», "
                                                   "«Актер», «Тормоз Вестингауза»",
                                           random_id=random.randint(0, 2 ** 64))
            elif "расскажи анекдот" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Сидят две девочки на крыше… Одна добрая, другая злая и кидают "
                                                   "камни в прохожих, злая попала 3 раза, а добрая 5… Потому что добро "
                                                   "ВСЕГДА побеждает зло!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "хочу шутку" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Урок химии.\n"
                                                   "Учительница:\n"
                                                   "- Маша, какого цвета у тебя раствор?\n"
                                                   "- Красного.\n"
                                                   "- Правильно. Садись, пять.\n"
                                                   "- Катя, а у тебя?\n"
                                                   "- Оранжевого.\n"
                                                   "- Не совсем правильно. Четыре, садись.\n"
                                                   "- Вовочка, цвет твоего раствора?\n"
                                                   "- Черный.\n"
                                                   "- Два. Класс! Ложись!!!!",
                                           random_id=random.randint(0, 2 ** 64))
            elif "посоветуй игры для компьютера" in request or "во что можно поиграть на компьютере?" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Могу посоветовать:\n"
                                                   "Genshin Impact\n"
                                                   "The Sims\n"
                                                   "Minecraft\n"
                                                   "PORTAL\n"
                                                   "CS:GO",
                                           random_id=random.randint(0, 2 ** 64))
            elif "посоветуй игры для телефона" in request or "во что можно поиграть на телефоне?" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Могу посоветовать:\n"
                                                   "Genshin Impact\n"
                                                   "The Sims\n"
                                                   "Minecraft\n"
                                                   "Doodle Jump\n"
                                                   "Dear My Cat\n"
                                                   "Sushi Bar\n"
                                                   "Flip the Frog\n"
                                                   "Color Switch",
                                           random_id=random.randint(0, 2 ** 64))
            elif "помощь" in request or "помоги мне" in request or "помоги" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message='Я могу просто поболтать, для этого напиши мне '
                                                   '"Который час?" или "Как дела?" или "Что делаешь?\n'
                                                   'Я могу показать вам фото Марса, для этого используйте команду-'
                                                   '"Картина дня"\n'
                                                   '"Я могу указать долготу и широту на '
                                                   'которых расположен заданный город (для этого пришлите его '
                                                   'название)\n'
                                                   ' или расстояние между городами (пришлите название двух городов '
                                                   'через пробел)',
                                           random_id=random.randint(0, 2 ** 64))
            elif "посоветуй игры для улицы" in request or "во что можно поиграть на улице?" in request:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Могу посоветовать:\n"
                                                   "Футбол\n"
                                                   "Баскетбол\n"
                                                   "Волейбол\n"
                                                   "Светофор\n"
                                                   "Картошка\n"
                                                   "Колечко\n"
                                                   "Вышибалы\n"
                                                   "Казаки-разбойники",
                                           random_id=random.randint(0, 2 ** 64))
            elif request in ("пока", 'до свидания', 'окончим разговор'):
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Пока",
                                           random_id=random.randint(0, 2 ** 64))
            elif request in ("картина дня", "фото дня"):
                NASA_API_KEY = '643g44LeTfWdhwFk6VRZ03NW2WOBhuBUCIvB7ngT'
                ROVER_URL = 'https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos'
                sol = random.randint(0, 1722)
                params = {'sol': sol, 'api_key': NASA_API_KEY}
                rev = random.choice(requests.get(ROVER_URL, params=params).json()['photos'])[
                    'img_src']
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message=rev,
                                           random_id=random.randint(0, 2 ** 64))
            elif len(request.split()) == 2 and (
                    request.split()[0] in town and request.split()[1] in town):
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message=str(round(
                                               get_distance(get_coordinates(request.split()[0]),
                                                            get_coordinates(
                                                                request.split()[1])))) + ' км',
                                           random_id=random.randint(0, 2 ** 64))
            elif request in town:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message=str(
                                               get_coordinates(request)) + ' - ' + get_country(
                                               request),
                                           random_id=random.randint(0, 2 ** 64))
            else:
                vk.get_api().messages.send(user_id=event.obj.message['from_id'],
                                           message="Не понял вашего ответа...",
                                           random_id=random.randint(0, 2 ** 64))


def get_coordinates(city_name):
    try:
        # url, по которому доступно API Яндекс.Карт
        url = "https://geocode-maps.yandex.ru/1.x/"
        # параметры запроса
        params = {
            "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
            # город, координаты которого мы ищем
            'geocode': city_name,
            # формат ответа от сервера, в данном случае JSON
            'format': 'json'
        }
        # отправляем запрос
        response = requests.get(url, params)
        # получаем JSON ответа
        json = response.json()
        # получаем координаты города
        # (там написаны долгота(longitude), широта(latitude) через пробел)
        # посмотреть подробное описание JSON-ответа можно
        # в документации по адресу https://tech.yandex.ru/maps/geocoder/
        coordinates_str = json['response']['GeoObjectCollection'][
            'featureMember'][0]['GeoObject']['Point']['pos']
        # Превращаем string в список, так как
        # точка - это пара двух чисел - координат
        long, lat = map(float, coordinates_str.split())
        # Вернем ответ
        return long, lat
    except Exception as e:
        return e


def get_distance(p1, p2):
    # p1 и p2 - это кортежи из двух элементов - координаты точек
    radius = 6373.0

    lon1 = math.radians(p1[0])
    lat1 = math.radians(p1[1])
    lon2 = math.radians(p2[0])
    lat2 = math.radians(p2[1])

    d_lon = lon2 - lon1
    d_lat = lat2 - lat1

    a = math.sin(d_lat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(d_lon / 2) ** 2
    c = 2 * math.atan2(a ** 0.5, (1 - a) ** 0.5)

    distance = radius * c
    return distance


def get_country(city_name):
    try:
        url = "https://geocode-maps.yandex.ru/1.x/"
        params = {
            "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
            'geocode': city_name,
            'format': 'json'
        }
        data = requests.get(url, params).json()
        # все отличие тут, мы получаем имя страны
        return data['response']['GeoObjectCollection'][
            'featureMember'][0]['GeoObject']['metaDataProperty'][
            'GeocoderMetaData']['AddressDetails']['Country']['CountryName']
    except Exception as e:
        return e


if __name__ == '__main__':
    main()
